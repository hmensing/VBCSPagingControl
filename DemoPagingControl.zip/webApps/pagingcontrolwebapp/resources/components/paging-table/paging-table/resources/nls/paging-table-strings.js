/**
  Copyright (c) 2015, 2019, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define({
  "root": {
    "paging-table" : {
    		"sampleString": "The strings file can be used to manage translatable resources"
    }
  }
});
define(['ojs/ojcore', 'text!./paging-table-view.html', './paging-table-viewModel', 'text!./component.json', 'css!./paging-table-styles', 'ojs/ojcomposite'],
  function(oj, view, viewModel, metadata) {
    oj.Composite.register('paging-table', {
      view: {inline: view}, 
      viewModel: {inline: viewModel}, 
      metadata: {inline: JSON.parse(metadata)}
    });
  }
);